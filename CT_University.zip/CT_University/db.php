<?php
/**
 * Direct reference alias to db_connect.php
 */
require_once __DIR__ . '/db_connect.php';
?>
