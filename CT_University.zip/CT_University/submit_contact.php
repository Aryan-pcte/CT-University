<?php
require_once __DIR__ . '/db_connect.php';

$errors = [];
$success = false;
$ticket_no = '';
$inserted_id = 0;
$inquiry_data = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Sanitize & extract inputs
    $full_name  = clean_input($_POST['full_name'] ?? '');
    $email      = clean_input($_POST['email'] ?? '');
    $phone      = clean_input($_POST['phone'] ?? '');
    $department = clean_input($_POST['department'] ?? '');
    $subject    = clean_input($_POST['subject'] ?? '');
    $message    = clean_input($_POST['message'] ?? '');

    // 2. Validate inputs
    if (empty($full_name))  $errors[] = "Full Name is required.";
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "A valid Email Address is required.";
    if (empty($phone))      $errors[] = "Phone Number is required.";
    if (empty($department)) $errors[] = "Department selection is required.";
    if (empty($subject))    $errors[] = "Subject is required.";
    if (empty($message))    $errors[] = "Message is required.";

    // 3. Save into Database if no errors
    if (empty($errors)) {
        try {
            $sql = "INSERT INTO contacts 
                    (full_name, email, phone, department, subject, message)
                    VALUES 
                    (:full_name, :email, :phone, :department, :subject, :message)";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':full_name'  => $full_name,
                ':email'      => $email,
                ':phone'      => $phone,
                ':department' => $department,
                ':subject'    => $subject,
                ':message'    => $message
            ]);

            $inserted_id = $pdo->lastInsertId();
            $ticket_no = "CTU-INQ-" . date("Y") . "-" . str_pad($inserted_id, 4, "0", STR_PAD_LEFT);
            $success = true;

            $inquiry_data = [
                'id'         => $inserted_id,
                'ticket_no'  => $ticket_no,
                'full_name'  => $full_name,
                'email'      => $email,
                'phone'      => $phone,
                'department' => $department,
                'subject'    => $subject,
                'message'    => $message,
                'time'       => date('d M Y, h:i A')
            ];

        } catch (PDOException $e) {
            $errors[] = "Database insertion failed: " . $e->getMessage();
        }
    }
} else {
    // If accessed via GET directly
    header("Location: Contact.html");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inquiry Received - CT University</title>
    <link rel="stylesheet" href="All_DESIGN.css">
    <style>
        .result-container {
            max-width: 750px;
            margin: 40px auto;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
            padding: 35px 40px;
            font-family: Arial, Helvetica, sans-serif;
        }
        .status-badge-success {
            background: #e8f5e9;
            border: 2px solid #2e7d32;
            color: #1b5e20;
            padding: 16px;
            border-radius: 8px;
            text-align: center;
            margin-bottom: 25px;
        }
        .status-badge-error {
            background: #ffebee;
            border: 2px solid #c62828;
            color: #b71c1c;
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 25px;
        }
        .status-badge-success h2 {
            margin: 0 0 8px 0;
            font-size: 26px;
            color: #2e7d32;
        }
        .status-badge-success p {
            margin: 0;
            font-size: 16px;
        }
        .ref-box {
            background: #f0f4f8;
            border-left: 5px solid #003366;
            padding: 15px 20px;
            margin-bottom: 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        .ref-box .label {
            font-weight: bold;
            color: #555;
            font-size: 14px;
        }
        .ref-box .value {
            font-size: 20px;
            font-weight: bold;
            color: #003366;
            letter-spacing: 1px;
        }
        .details-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        .details-table th, .details-table td {
            padding: 12px 16px;
            border-bottom: 1px solid #e0e0e0;
            text-align: left;
        }
        .details-table th {
            width: 30%;
            background: #f8fafc;
            color: #333;
            font-weight: 600;
        }
        .details-table td {
            color: #222;
        }
        .btn-group {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            justify-content: center;
            margin-top: 25px;
        }
        .btn {
            display: inline-block;
            padding: 12px 24px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
            font-size: 15px;
            cursor: pointer;
            border: none;
            transition: all 0.3s;
        }
        .btn-primary {
            background: #003366;
            color: #fff;
        }
        .btn-primary:hover {
            background: #0055aa;
        }
        .btn-secondary {
            background: #4caf50;
            color: #fff;
        }
        .btn-secondary:hover {
            background: #388e3c;
        }
        .btn-outline {
            background: #ffffff;
            color: #003366;
            border: 2px solid #003366;
        }
        .btn-outline:hover {
            background: #eef4fb;
        }
        .db-badge {
            display: inline-block;
            background: #e3f2fd;
            color: #0d47a1;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: bold;
            margin-top: 5px;
        }
    </style>
</head>
<body>

    <!--CT University Heading STARTS-->
    <div class="main_bg">
        <div class="logo"><img src="All_Images/Logo.jpeg" alt="CT University Logo"></div>
        <div class="main_heading">CT University</div>
    </div>
    <!--CT University Heading ENDS-->

    <!--Navbar STARTS-->
    <div class="navbar">
        <ul>
            <li><a href="home.html">HOME</a></li>
            <li><a href="About.html">ABOUT US</a></li>
            <li><a href="Admissions.html">ADMISSIONS</a></li>
            <li><a href="Departments.html">DEPARTMENTS</a></li>
            <li><a href="Contact.html">CONTACT</a></li>
            <li><a href="admin_dashboard.php">ADMIN / VIEW RECORDS</a></li>
        </ul>
    </div>
    <!--Navbar ENDS-->

    <div class="result-container">
        <?php if ($success): ?>
            <div class="status-badge-success">
                <h2>&#10004; Inquiry Sent Successfully!</h2>
                <p>Thank you for contacting CT University. Your inquiry has been stored in the database.</p>
                <span class="db-badge">Database Driver: <?php echo strtoupper($db_driver); ?> (Saved in Table: contacts)</span>
            </div>

            <div class="ref-box">
                <div>
                    <div class="label">INQUIRY TICKET NUMBER</div>
                    <div class="value"><?php echo htmlspecialchars($ticket_no); ?></div>
                </div>
                <div>
                    <div class="label">TIMESTAMP</div>
                    <div style="font-weight:600; color:#444;"><?php echo htmlspecialchars($inquiry_data['time']); ?></div>
                </div>
            </div>

            <h3 style="color:#003366; margin-bottom:15px; border-bottom:2px solid #003366; padding-bottom:6px;">Inquiry Details</h3>

            <table class="details-table">
                <tr>
                    <th>Full Name</th>
                    <td><?php echo htmlspecialchars($inquiry_data['full_name']); ?></td>
                </tr>
                <tr>
                    <th>Email Address</th>
                    <td><?php echo htmlspecialchars($inquiry_data['email']); ?></td>
                </tr>
                <tr>
                    <th>Phone Number</th>
                    <td><?php echo htmlspecialchars($inquiry_data['phone']); ?></td>
                </tr>
                <tr>
                    <th>Department</th>
                    <td><strong style="color:#003366;"><?php echo htmlspecialchars($inquiry_data['department']); ?></strong></td>
                </tr>
                <tr>
                    <th>Subject</th>
                    <td><?php echo htmlspecialchars($inquiry_data['subject']); ?></td>
                </tr>
                <tr>
                    <th>Message</th>
                    <td><?php echo nl2br(htmlspecialchars($inquiry_data['message'])); ?></td>
                </tr>
            </table>

            <div class="btn-group">
                <a href="Contact.html" class="btn btn-secondary">+ Submit Another Inquiry</a>
                <a href="admin_dashboard.php" class="btn btn-outline">&#128194; View Database Records</a>
                <a href="home.html" class="btn btn-primary">&#127968; Return to Home</a>
            </div>

        <?php else: ?>
            <div class="status-badge-error">
                <h2>&#10060; Inquiry Submission Failed</h2>
                <p>Please review and correct the following errors:</p>
                <ul style="margin: 10px 0 0 20px;">
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo htmlspecialchars($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div class="btn-group">
                <a href="javascript:history.back()" class="btn btn-primary">&#8592; Go Back and Correct Form</a>
                <a href="Contact.html" class="btn btn-outline">Back to Contact Page</a>
            </div>
        <?php endif; ?>
    </div>

    <div class="footer">CT_University_29-July-2026_Infotech-Internship | Form Database Integration</div>
</body>
</html>
