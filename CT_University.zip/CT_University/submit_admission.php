<?php
require_once __DIR__ . '/db_connect.php';

$errors = [];
$success = false;
$application_no = '';
$inserted_id = 0;
$submission_data = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Sanitize & extract inputs
    $first_name  = clean_input($_POST['first_name'] ?? '');
    $last_name   = clean_input($_POST['last_name'] ?? '');
    $email       = clean_input($_POST['email'] ?? '');
    $mobile      = clean_input($_POST['mobile'] ?? '');
    $dob         = clean_input($_POST['dob'] ?? '');
    $gender      = clean_input($_POST['gender'] ?? '');
    $nationality = clean_input($_POST['nationality'] ?? '');
    $course      = clean_input($_POST['course'] ?? '');
    $address     = clean_input($_POST['address'] ?? '');

    // 2. Validate required inputs
    if (empty($first_name))  $errors[] = "First Name is required.";
    if (empty($last_name))   $errors[] = "Last Name is required.";
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "A valid Email Address is required.";
    if (empty($mobile))      $errors[] = "Mobile Number is required.";
    if (empty($dob))         $errors[] = "Date of Birth is required.";
    if (empty($gender))      $errors[] = "Gender is required.";
    if (empty($nationality)) $errors[] = "Nationality is required.";
    if (empty($course))      $errors[] = "Course selection is required.";
    if (empty($address))     $errors[] = "Address is required.";

    // 3. Setup upload directories
    $upload_base = __DIR__ . '/uploads';
    $photo_dir   = $upload_base . '/photographs';
    $mark_dir    = $upload_base . '/marksheets';

    if (!is_dir($upload_base)) mkdir($upload_base, 0777, true);
    if (!is_dir($photo_dir))   mkdir($photo_dir, 0777, true);
    if (!is_dir($mark_dir))    mkdir($mark_dir, 0777, true);

    $photograph_path = null;
    $marksheet_path  = null;

    // 4. Handle Photograph upload
    if (isset($_FILES['photograph']) && $_FILES['photograph']['error'] === UPLOAD_ERR_OK) {
        $photo_file = $_FILES['photograph'];
        $ext = strtolower(pathinfo($photo_file['name'], PATHINFO_EXTENSION));
        $allowed_photo_exts = ['jpg', 'jpeg', 'png', 'webp'];

        if (!in_array($ext, $allowed_photo_exts)) {
            $errors[] = "Photograph must be an image file (JPG, PNG, WEBP).";
        } elseif ($photo_file['size'] > 5 * 1024 * 1024) {
            $errors[] = "Photograph file size must not exceed 5MB.";
        } else {
            $photo_filename = 'photo_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
            $destination = $photo_dir . '/' . $photo_filename;
            if (move_uploaded_file($photo_file['tmp_name'], $destination)) {
                $photograph_path = 'uploads/photographs/' . $photo_filename;
            } else {
                $errors[] = "Failed to upload photograph.";
            }
        }
    }

    // 5. Handle Marksheet upload
    if (isset($_FILES['marksheet']) && $_FILES['marksheet']['error'] === UPLOAD_ERR_OK) {
        $mark_file = $_FILES['marksheet'];
        $ext = strtolower(pathinfo($mark_file['name'], PATHINFO_EXTENSION));
        $allowed_mark_exts = ['pdf', 'jpg', 'jpeg', 'png', 'webp'];

        if (!in_array($ext, $allowed_mark_exts)) {
            $errors[] = "Marksheet must be a PDF or image file.";
        } elseif ($mark_file['size'] > 10 * 1024 * 1024) {
            $errors[] = "Marksheet file size must not exceed 10MB.";
        } else {
            $mark_filename = 'marksheet_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
            $destination = $mark_dir . '/' . $mark_filename;
            if (move_uploaded_file($mark_file['tmp_name'], $destination)) {
                $marksheet_path = 'uploads/marksheets/' . $mark_filename;
            } else {
                $errors[] = "Failed to upload marksheet.";
            }
        }
    }

    // 6. Save into Database if no errors
    if (empty($errors)) {
        try {
            $sql = "INSERT INTO admissions 
                    (first_name, last_name, email, mobile, dob, gender, nationality, course, address, photograph, marksheet)
                    VALUES 
                    (:first_name, :last_name, :email, :mobile, :dob, :gender, :nationality, :course, :address, :photograph, :marksheet)";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':first_name'  => $first_name,
                ':last_name'   => $last_name,
                ':email'       => $email,
                ':mobile'      => $mobile,
                ':dob'         => $dob,
                ':gender'      => $gender,
                ':nationality' => $nationality,
                ':course'      => $course,
                ':address'     => $address,
                ':photograph'  => $photograph_path,
                ':marksheet'   => $marksheet_path
            ]);

            $inserted_id = $pdo->lastInsertId();
            $application_no = "CTU-ADM-" . date("Y") . "-" . str_pad($inserted_id, 4, "0", STR_PAD_LEFT);
            $success = true;

            $submission_data = [
                'id'             => $inserted_id,
                'application_no' => $application_no,
                'name'           => $first_name . ' ' . $last_name,
                'email'          => $email,
                'mobile'         => $mobile,
                'dob'            => $dob,
                'gender'         => $gender,
                'nationality'    => $nationality,
                'course'         => $course,
                'address'        => $address,
                'photograph'     => $photograph_path,
                'marksheet'      => $marksheet_path,
                'time'           => date('d M Y, h:i A')
            ];

        } catch (PDOException $e) {
            $errors[] = "Database insertion failed: " . $e->getMessage();
        }
    }
} else {
    // If accessed via GET directly
    header("Location: Admissions.html");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admission Application Status - CT University</title>
    <link rel="stylesheet" href="All_DESIGN.css">
    <style>
        .result-container {
            max-width: 800px;
            margin: 40px auto;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
            padding: 35px 40px;
            font-family: Arial, Helvetica, sans-serif;
        }
        .status-badge-success {
            background: #e8f5e9;
            border: 2px solid #2e7d32;
            color: #1b5e20;
            padding: 16px;
            border-radius: 8px;
            text-align: center;
            margin-bottom: 25px;
        }
        .status-badge-error {
            background: #ffebee;
            border: 2px solid #c62828;
            color: #b71c1c;
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 25px;
        }
        .status-badge-success h2 {
            margin: 0 0 8px 0;
            font-size: 26px;
            color: #2e7d32;
        }
        .status-badge-success p {
            margin: 0;
            font-size: 16px;
        }
        .ref-box {
            background: #f0f4f8;
            border-left: 5px solid #003366;
            padding: 15px 20px;
            margin-bottom: 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        .ref-box .label {
            font-weight: bold;
            color: #555;
            font-size: 14px;
        }
        .ref-box .value {
            font-size: 20px;
            font-weight: bold;
            color: #003366;
            letter-spacing: 1px;
        }
        .details-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        .details-table th, .details-table td {
            padding: 12px 16px;
            border-bottom: 1px solid #e0e0e0;
            text-align: left;
        }
        .details-table th {
            width: 35%;
            background: #f8fafc;
            color: #333;
            font-weight: 600;
        }
        .details-table td {
            color: #222;
        }
        .btn-group {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            justify-content: center;
            margin-top: 25px;
        }
        .btn {
            display: inline-block;
            padding: 12px 24px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
            font-size: 15px;
            cursor: pointer;
            border: none;
            transition: all 0.3s;
        }
        .btn-primary {
            background: #003366;
            color: #fff;
        }
        .btn-primary:hover {
            background: #0055aa;
        }
        .btn-secondary {
            background: #4caf50;
            color: #fff;
        }
        .btn-secondary:hover {
            background: #388e3c;
        }
        .btn-outline {
            background: #ffffff;
            color: #003366;
            border: 2px solid #003366;
        }
        .btn-outline:hover {
            background: #eef4fb;
        }
        .file-link {
            color: #007bff;
            text-decoration: underline;
            font-weight: 500;
        }
        .db-badge {
            display: inline-block;
            background: #e3f2fd;
            color: #0d47a1;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: bold;
            margin-top: 5px;
        }
        @media print {
            .navbar, .btn-group, .footer, .db-badge {
                display: none !important;
            }
            .result-container {
                box-shadow: none;
                margin: 0;
                padding: 0;
            }
        }
    </style>
</head>
<body>

    <!--CT University Heading STARTS-->
    <div class="main_bg">
        <div class="logo"><img src="All_Images/Logo.jpeg" alt="CT University Logo"></div>
        <div class="main_heading">CT University</div>
    </div>
    <!--CT University Heading ENDS-->

    <!--Navbar STARTS-->
    <div class="navbar">
        <ul>
            <li><a href="home.html">HOME</a></li>
            <li><a href="About.html">ABOUT US</a></li>
            <li><a href="Admissions.html">ADMISSIONS</a></li>
            <li><a href="Departments.html">DEPARTMENTS</a></li>
            <li><a href="Contact.html">CONTACT</a></li>
            <li><a href="admin_dashboard.php">ADMIN / VIEW RECORDS</a></li>
        </ul>
    </div>
    <!--Navbar ENDS-->

    <div class="result-container">
        <?php if ($success): ?>
            <div class="status-badge-success">
                <h2>&#10004; Application Successfully Submitted!</h2>
                <p>Your admission application has been securely recorded and stored in the database.</p>
                <span class="db-badge">Database Driver: <?php echo strtoupper($db_driver); ?> (Saved in Table: admissions)</span>
            </div>

            <div class="ref-box">
                <div>
                    <div class="label">APPLICATION REFERENCE NUMBER</div>
                    <div class="value"><?php echo htmlspecialchars($application_no); ?></div>
                </div>
                <div>
                    <div class="label">SUBMISSION DATE & TIME</div>
                    <div style="font-weight:600; color:#444;"><?php echo htmlspecialchars($submission_data['time']); ?></div>
                </div>
            </div>

            <h3 style="color:#003366; margin-bottom:15px; border-bottom:2px solid #003366; padding-bottom:6px;">Applicant Details</h3>

            <table class="details-table">
                <tr>
                    <th>Full Name</th>
                    <td><?php echo htmlspecialchars($submission_data['name']); ?></td>
                </tr>
                <tr>
                    <th>Applied Course</th>
                    <td><strong style="color:#003366;"><?php echo htmlspecialchars($submission_data['course']); ?></strong></td>
                </tr>
                <tr>
                    <th>Email Address</th>
                    <td><?php echo htmlspecialchars($submission_data['email']); ?></td>
                </tr>
                <tr>
                    <th>Mobile Number</th>
                    <td><?php echo htmlspecialchars($submission_data['mobile']); ?></td>
                </tr>
                <tr>
                    <th>Date of Birth</th>
                    <td><?php echo htmlspecialchars($submission_data['dob']); ?></td>
                </tr>
                <tr>
                    <th>Gender</th>
                    <td><?php echo htmlspecialchars($submission_data['gender']); ?></td>
                </tr>
                <tr>
                    <th>Nationality</th>
                    <td><?php echo htmlspecialchars($submission_data['nationality']); ?></td>
                </tr>
                <tr>
                    <th>Residential Address</th>
                    <td><?php echo nl2br(htmlspecialchars($submission_data['address'])); ?></td>
                </tr>
                <tr>
                    <th>Photograph</th>
                    <td>
                        <?php if ($photograph_path): ?>
                            <a class="file-link" href="<?php echo htmlspecialchars($photograph_path); ?>" target="_blank">&#128065; View Uploaded Photograph</a>
                        <?php else: ?>
                            <span style="color:#888;">Not provided</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th>Marksheet / Documents</th>
                    <td>
                        <?php if ($marksheet_path): ?>
                            <a class="file-link" href="<?php echo htmlspecialchars($marksheet_path); ?>" target="_blank">&#128196; View Uploaded Marksheet</a>
                        <?php else: ?>
                            <span style="color:#888;">Not provided</span>
                        <?php endif; ?>
                    </td>
                </tr>
            </table>

            <div class="btn-group">
                <button onclick="window.print()" class="btn btn-primary">&#128438; Print / Save PDF</button>
                <a href="Admissions.html#Online_Apply" class="btn btn-secondary">+ Submit Another Application</a>
                <a href="admin_dashboard.php" class="btn btn-outline">&#128194; View Database Records</a>
                <a href="home.html" class="btn btn-outline">&#127968; Return to Home</a>
            </div>

        <?php else: ?>
            <div class="status-badge-error">
                <h2>&#10060; Application Submission Failed</h2>
                <p>Please review and correct the following errors:</p>
                <ul style="margin: 10px 0 0 20px;">
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo htmlspecialchars($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div class="btn-group">
                <a href="javascript:history.back()" class="btn btn-primary">&#8592; Go Back and Correct Form</a>
                <a href="Admissions.html" class="btn btn-outline">Back to Admissions Page</a>
            </div>
        <?php endif; ?>
    </div>

    <div class="footer">CT_University_29-July-2026_Infotech-Internship | Form Database Integration</div>
</body>
</html>
