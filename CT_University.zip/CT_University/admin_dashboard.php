<?php
require_once __DIR__ . '/db_connect.php';

// Handle Record Deletion if requested
$notice = '';
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['type']) && isset($_GET['id'])) {
    $delete_id = (int)$_GET['id'];
    $delete_type = $_GET['type'];
    
    if ($delete_type === 'admission') {
        // Optional: remove files
        $stmt_f = $pdo->prepare("SELECT photograph, marksheet FROM admissions WHERE id = :id");
        $stmt_f->execute([':id' => $delete_id]);
        $row_f = $stmt_f->fetch();
        if ($row_f) {
            if (!empty($row_f['photograph']) && file_exists(__DIR__ . '/' . $row_f['photograph'])) {
                @unlink(__DIR__ . '/' . $row_f['photograph']);
            }
            if (!empty($row_f['marksheet']) && file_exists(__DIR__ . '/' . $row_f['marksheet'])) {
                @unlink(__DIR__ . '/' . $row_f['marksheet']);
            }
        }
        $stmt = $pdo->prepare("DELETE FROM admissions WHERE id = :id");
        $stmt->execute([':id' => $delete_id]);
        $notice = "Admission record #$delete_id deleted successfully.";
    } elseif ($delete_type === 'contact') {
        $stmt = $pdo->prepare("DELETE FROM contacts WHERE id = :id");
        $stmt->execute([':id' => $delete_id]);
        $notice = "Contact inquiry #$delete_id deleted successfully.";
    }
}

// Fetch all admissions
$admissions = [];
try {
    $stmt = $pdo->query("SELECT * FROM admissions ORDER BY id DESC");
    $admissions = $stmt->fetchAll();
} catch (PDOException $e) {
    $admissions = [];
}

// Fetch all contacts
$contacts = [];
try {
    $stmt = $pdo->query("SELECT * FROM contacts ORDER BY id DESC");
    $contacts = $stmt->fetchAll();
} catch (PDOException $e) {
    $contacts = [];
}

$active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'admissions';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Portal - Database Submissions | CT University</title>
    <link rel="stylesheet" href="All_DESIGN.css">
    <style>
        .admin-wrapper {
            max-width: 1300px;
            margin: 30px auto;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.12);
            padding: 30px;
            font-family: Arial, Helvetica, sans-serif;
        }
        .admin-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #003366;
            padding-bottom: 15px;
            margin-bottom: 25px;
            flex-wrap: wrap;
            gap: 15px;
        }
        .admin-header h1 {
            color: #003366;
            font-size: 26px;
            margin: 0;
        }
        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin-bottom: 25px;
        }
        .stat-card {
            background: #f8fafc;
            border-left: 5px solid #003366;
            padding: 16px 20px;
            border-radius: 8px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.05);
        }
        .stat-card.green { border-left-color: #2e7d32; }
        .stat-card.orange { border-left-color: #e65100; }
        .stat-card .label { font-size: 13px; color: #666; font-weight: bold; text-transform: uppercase; }
        .stat-card .count { font-size: 26px; font-weight: bold; color: #003366; margin-top: 5px; }

        .tab-nav {
            display: flex;
            border-bottom: 2px solid #ddd;
            margin-bottom: 20px;
            gap: 10px;
        }
        .tab-btn {
            padding: 12px 24px;
            text-decoration: none;
            color: #555;
            font-weight: bold;
            border-bottom: 3px solid transparent;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .tab-btn.active {
            color: #003366;
            border-bottom-color: #003366;
            background: #f0f7ff;
            border-radius: 6px 6px 0 0;
        }
        .tab-btn:hover {
            color: #003366;
        }

        .table-responsive {
            width: 100%;
            overflow-x: auto;
            border-radius: 8px;
            border: 1px solid #e0e0e0;
        }
        table.data-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13.5px;
            text-align: left;
        }
        table.data-table th {
            background: #003366;
            color: #ffffff;
            padding: 12px 14px;
            font-weight: 600;
            white-space: nowrap;
        }
        table.data-table td {
            padding: 12px 14px;
            border-bottom: 1px solid #eee;
            vertical-align: middle;
        }
        table.data-table tr:nth-child(even) {
            background: #f9fbfd;
        }
        table.data-table tr:hover {
            background: #eef6ff;
        }

        .badge-course {
            background: #e1f5fe;
            color: #0277bd;
            font-weight: bold;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            display: inline-block;
        }
        .badge-dept {
            background: #f3e5f5;
            color: #7b1fa2;
            font-weight: bold;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            display: inline-block;
        }
        .btn-view-doc {
            background: #007bff;
            color: white;
            padding: 4px 10px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 12px;
            display: inline-block;
            margin: 2px 0;
        }
        .btn-view-doc:hover { background: #0056b3; }
        .btn-del {
            background: #d32f2f;
            color: white;
            padding: 4px 8px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 12px;
            display: inline-block;
        }
        .btn-del:hover { background: #b71c1c; }
        .empty-state {
            padding: 40px;
            text-align: center;
            color: #777;
            font-size: 16px;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            padding: 12px 18px;
            border-radius: 6px;
            margin-bottom: 20px;
            border: 1px solid #c3e6cb;
        }
        .driver-badge {
            background: #e8f5e9;
            color: #2e7d32;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }
        .thumbnail-img {
            width: 45px;
            height: 45px;
            object-fit: cover;
            border-radius: 4px;
            border: 1px solid #ccc;
            cursor: pointer;
        }
    </style>
</head>
<body>

    <!--CT University Heading STARTS-->
    <div class="main_bg">
        <div class="logo"><img src="All_Images/Logo.jpeg" alt="CT University Logo"></div>
        <div class="main_heading">CT University</div>
    </div>
    <!--CT University Heading ENDS-->

    <!--Navbar STARTS-->
    <div class="navbar">
        <ul>
            <li><a href="home.html">HOME</a></li>
            <li><a href="About.html">ABOUT US</a></li>
            <li><a href="Admissions.html">ADMISSIONS</a></li>
            <li><a href="Departments.html">DEPARTMENTS</a></li>
            <li><a href="Contact.html">CONTACT</a></li>
            <li><a href="admin_dashboard.php" style="background:#0055aa;">ADMIN / VIEW RECORDS</a></li>
        </ul>
    </div>
    <!--Navbar ENDS-->

    <div class="admin-wrapper">
        <div class="admin-header">
            <div>
                <h1>&#128194; Database Records & Form Submissions</h1>
                <p style="color:#666; margin-top:5px; font-size:14px;">Real-time database storage for Online Admission Applications and Contact Inquiries.</p>
            </div>
            <div>
                <span class="driver-badge">&#9679; Connected via <?php echo strtoupper($db_driver); ?> Database</span>
            </div>
        </div>

        <?php if (!empty($notice)): ?>
            <div class="alert-success">&#10004; <?php echo htmlspecialchars($notice); ?></div>
        <?php endif; ?>

        <!-- Stats Overview -->
        <div class="stats-cards">
            <div class="stat-card green">
                <div class="label">Total Admissions Stored</div>
                <div class="count"><?php echo count($admissions); ?></div>
            </div>
            <div class="stat-card orange">
                <div class="label">Total Inquiries Stored</div>
                <div class="count"><?php echo count($contacts); ?></div>
            </div>
            <div class="stat-card">
                <div class="label">Database Name</div>
                <div class="count" style="font-size:18px; margin-top:10px;"><?php echo $db_driver === 'mysql' ? DB_NAME : 'ct_university.db (SQLite)'; ?></div>
            </div>
        </div>

        <!-- Navigation Tabs -->
        <div class="tab-nav">
            <a href="admin_dashboard.php?tab=admissions" class="tab-btn <?php echo $active_tab === 'admissions' ? 'active' : ''; ?>">
                &#127891; Admission Applications (<?php echo count($admissions); ?>)
            </a>
            <a href="admin_dashboard.php?tab=contacts" class="tab-btn <?php echo $active_tab === 'contacts' ? 'active' : ''; ?>">
                &#9993; Contact Inquiries (<?php echo count($contacts); ?>)
            </a>
        </div>

        <!-- Admissions Table Tab -->
        <?php if ($active_tab === 'admissions'): ?>
            <div class="table-responsive">
                <?php if (count($admissions) > 0): ?>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>#ID</th>
                                <th>App No</th>
                                <th>Applicant Name</th>
                                <th>Course</th>
                                <th>Email</th>
                                <th>Mobile</th>
                                <th>DOB</th>
                                <th>Gender</th>
                                <th>Nationality</th>
                                <th>Address</th>
                                <th>Documents</th>
                                <th>Submitted At</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($admissions as $row): ?>
                                <tr>
                                    <td><strong>#<?php echo $row['id']; ?></strong></td>
                                    <td style="color:#003366; font-weight:bold;">
                                        CTU-ADM-<?php echo date('Y', strtotime($row['created_at'])); ?>-<?php echo str_pad($row['id'], 4, '0', STR_PAD_LEFT); ?>
                                    </td>
                                    <td><strong><?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?></strong></td>
                                    <td><span class="badge-course"><?php echo htmlspecialchars($row['course']); ?></span></td>
                                    <td><a href="mailto:<?php echo htmlspecialchars($row['email']); ?>"><?php echo htmlspecialchars($row['email']); ?></a></td>
                                    <td><?php echo htmlspecialchars($row['mobile']); ?></td>
                                    <td><?php echo htmlspecialchars($row['dob']); ?></td>
                                    <td><?php echo htmlspecialchars($row['gender']); ?></td>
                                    <td><?php echo htmlspecialchars($row['nationality']); ?></td>
                                    <td title="<?php echo htmlspecialchars($row['address']); ?>">
                                        <?php echo htmlspecialchars(mb_strimwidth($row['address'], 0, 25, '...')); ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($row['photograph'])): ?>
                                            <a class="btn-view-doc" href="<?php echo htmlspecialchars($row['photograph']); ?>" target="_blank">&#128247; Photo</a><br>
                                        <?php endif; ?>
                                        <?php if (!empty($row['marksheet'])): ?>
                                            <a class="btn-view-doc" style="background:#28a745;" href="<?php echo htmlspecialchars($row['marksheet']); ?>" target="_blank">&#128196; Marksheet</a>
                                        <?php endif; ?>
                                        <?php if (empty($row['photograph']) && empty($row['marksheet'])): ?>
                                            <span style="color:#aaa; font-size:12px;">None</span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="white-space:nowrap; font-size:12px; color:#555;">
                                        <?php echo date('d M Y, h:i A', strtotime($row['created_at'])); ?>
                                    </td>
                                    <td>
                                        <a href="admin_dashboard.php?action=delete&type=admission&id=<?php echo $row['id']; ?>&tab=admissions" 
                                           class="btn-del" 
                                           onclick="return confirm('Are you sure you want to delete application #<?php echo $row['id']; ?>?');">
                                           Delete
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="empty-state">
                        <p>No admission applications have been submitted yet.</p>
                        <a href="Admissions.html#Online_Apply" style="color:#003366; font-weight:bold; text-decoration:underline;">Click here to submit a test application &rarr;</a>
                    </div>
                <?php endif; ?>
            </div>

        <!-- Contact Inquiries Table Tab -->
        <?php else: ?>
            <div class="table-responsive">
                <?php if (count($contacts) > 0): ?>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>#ID</th>
                                <th>Ticket No</th>
                                <th>Sender Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Department</th>
                                <th>Subject</th>
                                <th>Message</th>
                                <th>Submitted At</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($contacts as $row): ?>
                                <tr>
                                    <td><strong>#<?php echo $row['id']; ?></strong></td>
                                    <td style="color:#003366; font-weight:bold;">
                                        CTU-INQ-<?php echo date('Y', strtotime($row['created_at'])); ?>-<?php echo str_pad($row['id'], 4, '0', STR_PAD_LEFT); ?>
                                    </td>
                                    <td><strong><?php echo htmlspecialchars($row['full_name']); ?></strong></td>
                                    <td><a href="mailto:<?php echo htmlspecialchars($row['email']); ?>"><?php echo htmlspecialchars($row['email']); ?></a></td>
                                    <td><?php echo htmlspecialchars($row['phone']); ?></td>
                                    <td><span class="badge-dept"><?php echo htmlspecialchars($row['department']); ?></span></td>
                                    <td><strong><?php echo htmlspecialchars($row['subject']); ?></strong></td>
                                    <td style="max-width:300px;"><?php echo nl2br(htmlspecialchars($row['message'])); ?></td>
                                    <td style="white-space:nowrap; font-size:12px; color:#555;">
                                        <?php echo date('d M Y, h:i A', strtotime($row['created_at'])); ?>
                                    </td>
                                    <td>
                                        <a href="admin_dashboard.php?action=delete&type=contact&id=<?php echo $row['id']; ?>&tab=contacts" 
                                           class="btn-del" 
                                           onclick="return confirm('Are you sure you want to delete inquiry #<?php echo $row['id']; ?>?');">
                                           Delete
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="empty-state">
                        <p>No contact inquiries have been submitted yet.</p>
                        <a href="Contact.html" style="color:#003366; font-weight:bold; text-decoration:underline;">Click here to submit an inquiry &rarr;</a>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div style="margin-top:25px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
            <div>
                <a href="Admissions.html" style="color:#003366; font-weight:bold; margin-right:15px; text-decoration:none;">&larr; Admissions Form</a>
                <a href="Contact.html" style="color:#003366; font-weight:bold; text-decoration:none;">&larr; Contact Form</a>
            </div>
            <button onclick="window.print()" style="padding:8px 18px; background:#003366; color:#fff; border:none; border-radius:5px; cursor:pointer; font-weight:bold;">
                &#128438; Print Submissions Report
            </button>
        </div>
    </div>

    <div class="footer">CT_University_29-July-2026_Infotech-Internship | Admin Dashboard</div>
</body>
</html>
