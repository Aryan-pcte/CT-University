<?php
/**
 * Setup and Diagnostics Script
 * CT University Database Integration
 */
require_once __DIR__ . '/db_connect.php';

$message = '';
$message_type = 'info';

if (isset($_POST['seed_data'])) {
    try {
        // Insert sample admission
        $stmt_adm = $pdo->prepare("
            INSERT INTO admissions 
            (first_name, last_name, email, mobile, dob, gender, nationality, course, address)
            VALUES 
            (:fn, :ln, :em, :mb, :dob, :gen, :nat, :crs, :addr)
        ");
        $stmt_adm->execute([
            ':fn'   => 'Rohan',
            ':ln'   => 'Sharma',
            ':em'   => 'rohan.sharma@example.com',
            ':mb'   => '+91 9876543210',
            ':dob'  => '2004-05-15',
            ':gen'  => 'Male',
            ':nat'  => 'Indian',
            ':crs'  => 'B.Tech',
            ':addr' => 'Sector 14, Ludhiana, Punjab'
        ]);

        // Insert sample inquiry
        $stmt_cnt = $pdo->prepare("
            INSERT INTO contacts 
            (full_name, email, phone, department, subject, message)
            VALUES 
            (:fn, :em, :ph, :dept, :sub, :msg)
        ");
        $stmt_cnt->execute([
            ':fn'   => 'Priya Patel',
            ':em'   => 'priya.patel@example.com',
            ':ph'   => '+91 9123456780',
            ':dept' => 'Admissions',
            ':sub'  => 'Inquiry regarding B.Tech Computer Science syllabus',
            ':msg'  => 'Hello, I would like more details about the robotics and AI lab curriculum for B.Tech CSE.'
        ]);

        $message = "Sample test records inserted successfully into database!";
        $message_type = "success";
    } catch (PDOException $e) {
        $message = "Error inserting test records: " . $e->getMessage();
        $message_type = "error";
    }
}

// Table verification
$tables_status = [];
try {
    $count_adm = $pdo->query("SELECT COUNT(*) FROM admissions")->fetchColumn();
    $tables_status['admissions'] = ['status' => 'OK', 'count' => $count_adm];
} catch (Exception $e) {
    $tables_status['admissions'] = ['status' => 'Error: ' . $e->getMessage(), 'count' => 0];
}

try {
    $count_cnt = $pdo->query("SELECT COUNT(*) FROM contacts")->fetchColumn();
    $tables_status['contacts'] = ['status' => 'OK', 'count' => $count_cnt];
} catch (Exception $e) {
    $tables_status['contacts'] = ['status' => 'Error: ' . $e->getMessage(), 'count' => 0];
}

// Upload directory checks
$uploads_ok = is_dir(__DIR__ . '/uploads') && is_writable(__DIR__ . '/uploads');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Setup & Diagnostics - CT University</title>
    <link rel="stylesheet" href="All_DESIGN.css">
    <style>
        .diag-container {
            max-width: 800px;
            margin: 40px auto;
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.12);
            font-family: Arial, Helvetica, sans-serif;
        }
        .diag-title {
            color: #003366;
            margin-bottom: 20px;
            border-bottom: 2px solid #003366;
            padding-bottom: 10px;
        }
        .diag-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 16px;
            border-bottom: 1px solid #eee;
        }
        .badge-ok {
            background: #e8f5e9;
            color: #2e7d32;
            padding: 4px 12px;
            border-radius: 20px;
            font-weight: bold;
            font-size: 13px;
        }
        .badge-err {
            background: #ffebee;
            color: #c62828;
            padding: 4px 12px;
            border-radius: 20px;
            font-weight: bold;
            font-size: 13px;
        }
        .btn {
            background: #003366;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
            text-decoration: none;
            display: inline-block;
        }
        .btn:hover { background: #0055aa; }
        .alert {
            padding: 12px 18px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-weight: bold;
        }
        .alert.success { background: #d4edda; color: #155724; }
        .alert.error { background: #f8d7da; color: #721c24; }
    </style>
</head>
<body>
    <div class="main_bg">
        <div class="logo"><img src="All_Images/Logo.jpeg" alt="CT University Logo"></div>
        <div class="main_heading">CT University</div>
    </div>

    <div class="navbar">
        <ul>
            <li><a href="home.html">HOME</a></li>
            <li><a href="Admissions.html">ADMISSIONS</a></li>
            <li><a href="Contact.html">CONTACT</a></li>
            <li><a href="admin_dashboard.php">ADMIN / VIEW RECORDS</a></li>
        </ul>
    </div>

    <div class="diag-container">
        <h2 class="diag-title">&#128736; Database Setup & Diagnostic Status</h2>

        <?php if (!empty($message)): ?>
            <div class="alert <?php echo $message_type; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <div class="diag-item">
            <div>
                <strong>Database Engine</strong>
                <div style="color:#666; font-size:12px;">Active connection driver</div>
            </div>
            <div>
                <span class="badge-ok"><?php echo strtoupper($db_driver); ?></span>
            </div>
        </div>

        <div class="diag-item">
            <div>
                <strong>Database / File Name</strong>
                <div style="color:#666; font-size:12px;">Storage container</div>
            </div>
            <div>
                <span style="font-weight:bold; color:#003366;"><?php echo $db_driver === 'mysql' ? DB_NAME : 'ct_university.db'; ?></span>
            </div>
        </div>

        <div class="diag-item">
            <div>
                <strong>Admissions Table</strong>
                <div style="color:#666; font-size:12px;">Stores online student application forms</div>
            </div>
            <div>
                <?php if ($tables_status['admissions']['status'] === 'OK'): ?>
                    <span class="badge-ok">&#10004; Active (<?php echo $tables_status['admissions']['count']; ?> records)</span>
                <?php else: ?>
                    <span class="badge-err"><?php echo $tables_status['admissions']['status']; ?></span>
                <?php endif; ?>
            </div>
        </div>

        <div class="diag-item">
            <div>
                <strong>Contacts Table</strong>
                <div style="color:#666; font-size:12px;">Stores contact & inquiry form submissions</div>
            </div>
            <div>
                <?php if ($tables_status['contacts']['status'] === 'OK'): ?>
                    <span class="badge-ok">&#10004; Active (<?php echo $tables_status['contacts']['count']; ?> records)</span>
                <?php else: ?>
                    <span class="badge-err"><?php echo $tables_status['contacts']['status']; ?></span>
                <?php endif; ?>
            </div>
        </div>

        <div class="diag-item">
            <div>
                <strong>File Upload Directory (`uploads/`)</strong>
                <div style="color:#666; font-size:12px;">Stores student photographs and marksheets</div>
            </div>
            <div>
                <?php if ($uploads_ok): ?>
                    <span class="badge-ok">&#10004; Writable</span>
                <?php else: ?>
                    <span class="badge-err">Check Permissions</span>
                <?php endif; ?>
            </div>
        </div>

        <div style="margin-top:25px; display:flex; gap:12px; flex-wrap:wrap;">
            <form method="POST">
                <button type="submit" name="seed_data" class="btn" style="background:#28a745;">
                    + Insert Sample Test Data
                </button>
            </form>
            <a href="admin_dashboard.php" class="btn">&#128194; Open Admin Dashboard</a>
            <a href="Admissions.html" class="btn" style="background:#17a2b8;">Open Admission Form</a>
        </div>
    </div>

    <div class="footer">CT_University_29-July-2026_Infotech-Internship | System Setup</div>
</body>
</html>
