<?php
/**
 * Database Connection & Auto-Initialization Script
 * CT University Web Portal
 * 
 * Supports:
 * 1. MySQL / MariaDB (Default: localhost, user: root, pass: empty)
 * 2. Automatic database creation (ct_university_db)
 * 3. Automatic table creation (admissions, contacts)
 * 4. Automatic SQLite fallback if MySQL server is not running
 */

// MySQL Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'ct_university_db');
define('DB_USER', 'root');
define('DB_PASS', '');

$pdo = null;
$db_driver = 'mysql';
$db_error = null;

try {
    // Step 1: Connect to MySQL host to ensure database exists
    $init_pdo = new PDO("mysql:host=" . DB_HOST . ";charset=utf8mb4", DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_TIMEOUT => 2
    ]);
    
    // Create database if not exists
    $init_pdo->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $init_pdo = null;

    // Step 2: Connect to the specific database
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false
    ]);
    $db_driver = 'mysql';

    // Step 3: Create tables if not exists
    $admissions_table_sql = "
    CREATE TABLE IF NOT EXISTS `admissions` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `first_name` VARCHAR(100) NOT NULL,
        `last_name` VARCHAR(100) NOT NULL,
        `email` VARCHAR(150) NOT NULL,
        `mobile` VARCHAR(25) NOT NULL,
        `dob` DATE NOT NULL,
        `gender` VARCHAR(20) NOT NULL,
        `nationality` VARCHAR(100) NOT NULL,
        `course` VARCHAR(100) NOT NULL,
        `address` TEXT NOT NULL,
        `photograph` VARCHAR(255) DEFAULT NULL,
        `marksheet` VARCHAR(255) DEFAULT NULL,
        `status` VARCHAR(50) DEFAULT 'Pending',
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
    
    $contacts_table_sql = "
    CREATE TABLE IF NOT EXISTS `contacts` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `full_name` VARCHAR(150) NOT NULL,
        `email` VARCHAR(150) NOT NULL,
        `phone` VARCHAR(25) NOT NULL,
        `department` VARCHAR(100) NOT NULL,
        `subject` VARCHAR(255) NOT NULL,
        `message` TEXT NOT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

    $pdo->exec($admissions_table_sql);
    $pdo->exec($contacts_table_sql);

} catch (PDOException $e) {
    // If MySQL connection fails, fallback seamlessly to SQLite
    try {
        $sqlite_path = __DIR__ . '/ct_university.db';
        $pdo = new PDO("sqlite:" . $sqlite_path);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $db_driver = 'sqlite';

        // SQLite table initialization
        $sqlite_admissions = "
        CREATE TABLE IF NOT EXISTS admissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL,
            email TEXT NOT NULL,
            mobile TEXT NOT NULL,
            dob TEXT NOT NULL,
            gender TEXT NOT NULL,
            nationality TEXT NOT NULL,
            course TEXT NOT NULL,
            address TEXT NOT NULL,
            photograph TEXT DEFAULT NULL,
            marksheet TEXT DEFAULT NULL,
            status TEXT DEFAULT 'Pending',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );";

        $sqlite_contacts = "
        CREATE TABLE IF NOT EXISTS contacts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            email TEXT NOT NULL,
            phone TEXT NOT NULL,
            department TEXT NOT NULL,
            subject TEXT NOT NULL,
            message TEXT NOT NULL,
            status TEXT DEFAULT 'New',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );";

        $pdo->exec($sqlite_admissions);
        $pdo->exec($sqlite_contacts);

    } catch (PDOException $sqle) {
        $db_error = "Database Error: " . $sqle->getMessage();
    }
}

/**
 * Helper function to sanitize user inputs
 */
function clean_input($data) {
    if (is_null($data)) return '';
    return trim(stripslashes($data));
}
?>
