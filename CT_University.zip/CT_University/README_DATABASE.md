# CT University – MySQL Form Database

This project now stores the data submitted through the two HTML forms in a MySQL database.

## Forms connected to the database

### 1. Online Admission Form
- Page: `Admissions.html`
- Handler: `submit_admission.php`
- Database table: `admissions`
- Stores:
  - First name
  - Last name
  - Email
  - Mobile
  - Date of birth
  - Gender
  - Nationality
  - Course
  - Address
  - Photograph path
  - Marksheet path
  - Submission date/time

### 2. Contact Form
- Page: `Contact.html`
- Handler: `submit_contact.php`
- Database table: `contacts`
- Stores:
  - Full name
  - Email
  - Phone
  - Department
  - Subject
  - Message
  - Submission date/time

## How the connection works

`Admissions.html` and `Contact.html` submit their forms using `POST` to PHP files.  
The PHP files use `db_connect.php`, which connects to MySQL with PDO and creates the database/tables automatically if they do not already exist.

Database name:

`ct_university_db`

Default XAMPP MySQL settings:

- Host: `localhost`
- Username: `root`
- Password: empty

If your MySQL username/password is different, edit the values at the top of `db_connect.php`.

## Run the project with XAMPP

1. Install/start XAMPP.
2. Start **Apache**.
3. Start **MySQL**.
4. Put the complete `CT_University` folder inside:
   `C:\xampp\htdocs\`
5. Open:
   `http://localhost/CT_University/Admissions.html`
6. Submit an admission application.
7. Open:
   `http://localhost/CT_University/Contact.html`
8. Submit a contact inquiry.
9. View saved records at:
   `http://localhost/CT_University/admin_dashboard.php`

## MySQL / phpMyAdmin

The included `database.sql` can also be imported manually through phpMyAdmin.

Database:
`ct_university_db`

Tables:
- `admissions`
- `contacts`

The PHP connection file also creates these tables automatically, so manual import is optional.

## Important

Do **not** open the HTML files by double-clicking them (`file:///...`).  
Use Apache and open them through `http://localhost/...`, because PHP cannot execute when the page is opened directly as a local HTML file.

Uploaded photographs and marksheets are stored under:

- `uploads/photographs/`
- `uploads/marksheets/`

The included `uploads/.htaccess` prevents PHP scripts from being executed from the upload directory.
